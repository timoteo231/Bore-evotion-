# Como enviar o Body Evolution para o GitHub

## Criar o repositório
1. Acesse https://github.com/new
2. Nome sugerido: `body-evolution`.
3. Selecione **Private** (recomendado enquanto o aplicativo está em desenvolvimento).
4. Não marque para adicionar README, `.gitignore` ou licença: estes arquivos já estão no pacote.
5. Crie o repositório.

## Enviar os arquivos
1. Extraia o arquivo ZIP no computador.
2. Abra a pasta `body-evolution` extraída.
3. Envie o CONTEÚDO dessa pasta para a raiz do repositório (não envie apenas o ZIP).
4. Confirme que `package.json`, `README.md`, `src/` e `supabase/` aparecem na raiz do GitHub.
5. Faça o commit na branch `main`.

No GitHub pelo navegador, use **Add file > Upload files**. Se estiver no celular e não conseguir enviar a pasta inteira, use GitHub Desktop em um computador ou um cliente Git confiável.

## Segurança
- Não envie `.env.local`, senhas, tokens, chaves `service_role` ou arquivos de credenciais.
- O pacote contém apenas `.env.example` com valores ilustrativos.
- Não torne o repositório público nesta fase.

## Depois do envio
Envie o endereço completo do repositório, por exemplo:
`https://github.com/SEU_USUARIO/body-evolution`

Assim será possível vinculá-lo ao projeto `body-evolution` já criado na Vercel e iniciar a compilação/deploy.
