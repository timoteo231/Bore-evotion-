# BODY EVOLUTION — Starter Kit 1.1

Aplicação inicial em Next.js + TypeScript + Supabase, com identidade premium escura, autenticação, área administrativa, cadastro de alunos e registro de avaliação física com cálculo de IMC.

> **Importante:** a versão 1.1 **não foi compilada nem executada** pelo autor das alterações (sem acesso à internet para instalar dependências). Rode `npm install`, `npm run typecheck`, `npm run build` e `npm test` e corrija eventuais erros antes de publicar. Ainda faltam testes de integração e ponta a ponta, formulário de medidas corporais e metas, notificações, backup/monitoramento e revisão jurídica (LGPD) antes de usar com dados reais.

## Requisitos
- Node.js 20.9 ou superior
- Conta Supabase
- Conta Vercel (para publicação)

## 1. Instalar

```bash
npm install
cp .env.example .env.local
```

Preencha `.env.local` com a URL e a chave pública/anon do seu projeto Supabase. Não coloque a service role em variável `NEXT_PUBLIC_` e não compartilhe o arquivo `.env.local`.

## 2. Configurar o banco

1. Crie um projeto no Supabase.
2. Abra SQL Editor.
3. Execute `supabase/migrations/0001_initial_schema.sql` e, em seguida, `supabase/migrations/0002_fixes_and_features.sql` (funções atômicas, auditoria, índice de e-mail único e dados iniciais de exercícios e alimentos).
4. Confira se as tabelas e políticas RLS foram criadas.

## 3. Criar o primeiro administrador

1. No Supabase, abra Authentication > Users e crie/invite seu usuário de administrador.
2. Confirme o usuário e seu e-mail.
3. No SQL Editor, execute substituindo pelo seu e-mail:

```sql
update public.profiles
set role = 'admin'
where email = 'SEU_EMAIL';
```

Não disponibilize essa operação na interface pública. Somente o proprietário confiável deve promover a conta inicial.

## 4. Criar acesso de aluno (novo: convite pelo app)

No painel, abra o aluno e use **Enviar convite por e-mail**. O app cria o usuário no Supabase Auth, vincula `students.user_id` e o aluno define a senha pelo link. Requer `SUPABASE_SERVICE_ROLE_KEY` apenas no servidor (Vercel > Environment Variables, sem `NEXT_PUBLIC_`).

**Configure os e-mails no Supabase** (Authentication > Email Templates) para que os links funcionem:
- Invite user: `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=invite&next=/auth/definir-senha`
- Reset password: `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery&next=/auth/definir-senha`

Em Authentication > URL Configuration, defina o Site URL e inclua `SEU_DOMINIO/auth/confirm` nos redirects permitidos.

Método manual (alternativa):

Nesta versão inicial, o cadastro administrativo cria o registro do aluno, mas ainda não envia convite de autenticação automaticamente. Para vincular um usuário aluno:

1. Crie/invite o usuário em Supabase Authentication.
2. Localize o UUID desse usuário.
3. Vincule o usuário ao cadastro correspondente, usando SQL administrativo:

```sql
update public.students
set user_id = 'UUID_DO_USUARIO'
where email = 'EMAIL_DO_ALUNO';
```

O usuário deve permanecer com papel `student` em `profiles`.

## 5. Executar localmente

```bash
npm run dev
```
Acesse http://localhost:3000.

## 6. Publicar na Vercel

1. Envie o repositório para GitHub.
2. Importe o repositório na Vercel.
3. Configure `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` nas variáveis de ambiente.
4. Configure `NEXT_PUBLIC_APP_URL` com o domínio publicado.
5. Faça o deploy.
6. Configure no Supabase Authentication > URL Configuration a URL do site e os redirects permitidos.

## Novidades da 1.1
- `middleware.ts`: renova a sessão e barra visitantes em /admin, /aluno e /dashboard.
- Convite de aluno por e-mail, definição e recuperação de senha.
- Edição de status do aluno (inativar/reativar) e página de detalhe com avaliações e gráfico de peso.
- Avaliação gravada em transação única, agora com TMB e gasto diário (usa sexo e nascimento do aluno).
- Treinos: biblioteca de exercícios, criação de fichas, atribuição ao aluno e registro de séries com timer de descanso.
- Dieta: plano alimentar com nutricionista responsável (nome e CRN obrigatórios), atribuição e visão do aluno com macros.
- Auditoria de ações administrativas em `audit_logs`; erros internos não vazam para o cliente.
- Políticas de privacidade e termos (modelos para revisão jurídica), ícones PWA.
- Testes unitários (`npm test`) e roteiro manual de acesso cruzado em `supabase/tests/rls_cross_access.sql`.

## Funcionalidades incluídas (base 1.0)
- Landing page Body Evolution.
- Login com Supabase Auth.
- Redirecionamento por papel de usuário.
- Painel administrativo de alunos.
- Cadastro básico de aluno.
- Formulário administrativo de avaliação física.
- Cálculo e gravação de IMC.
- Área inicial do aluno com leitura de peso e IMC.
- Migração SQL com tabelas centrais e políticas RLS iniciais.
- Fórmulas isoladas para IMC, TMB e TDEE.

## Antes de produção — checklist obrigatório
- Revisar as políticas RLS com testes de acesso cruzado entre usuários.
- Implementar convite de alunos pelo backend seguro e fluxo de recuperação de senha.
- Completar operações CRUD e validações de todos os módulos.
- Implementar treinos, logs, planos nutricionais e gráficos.
- Adicionar testes unitários, integração e ponta a ponta.
- Configurar backup, monitoramento, retenção e resposta a incidentes.
- Revisar LGPD, consentimentos, política de privacidade e termos.
- Obter revisão técnica de segurança antes de armazenar dados reais.

## Observação sobre saúde e nutrição
IMC é um indicador de triagem e não diferencia massa muscular de gordura. TMB/TDEE são estimativas. Prescrição individual de dieta deve ser realizada/validada por nutricionista habilitado. Não utilizar os cálculos como diagnóstico.
