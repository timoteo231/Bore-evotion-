-- Teste manual de acesso cruzado (SQL Editor do Supabase, ambiente de desenvolvimento).
-- 1) Crie dois alunos A e B com login e vínculo (students.user_id).
-- 2) Substitua os UUIDs abaixo pelos user_id (auth.users.id) de A e o student.id de B.
-- 3) Rode. Todas as consultas devem retornar 0 linhas / falhar.
begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub','UUID_USER_ALUNO_A','role','authenticated')::text, true);

select count(*) as deve_ser_0 from public.students      where id = 'UUID_STUDENT_B';
select count(*) as deve_ser_0 from public.assessments   where student_id = 'UUID_STUDENT_B';
select count(*) as deve_ser_0 from public.workout_logs  where student_id = 'UUID_STUDENT_B';
select count(*) as deve_ser_0 from public.audit_logs;
-- Deve falhar (violação de RLS):
-- insert into public.workout_logs(assignment_id, student_id) values ('UUID_ASSIGNMENT_QUALQUER','UUID_STUDENT_B');
-- update public.profiles set role = 'admin' where id = 'UUID_USER_ALUNO_A';
rollback;
