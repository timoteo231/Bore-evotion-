create extension if not exists pgcrypto;

do $$ begin create type public.user_role as enum ('admin','student'); exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '', email text not null default '',
 role public.user_role not null default 'student', avatar_url text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.students (
 id uuid primary key default gen_random_uuid(), user_id uuid unique references auth.users(id),
 created_by uuid not null references public.profiles(id), full_name text not null,
 email text not null, birth_date date, sex text check(sex in ('male','female','other','not_informed')),
 height_cm numeric(5,2) check(height_cm is null or height_cm between 1 and 250),
 objective text not null default 'hypertrophy' check(objective in ('hypertrophy','weight_loss','conditioning','maintenance')),
 status text not null default 'active' check(status in ('active','inactive')),
 start_date date not null default current_date, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.assessments (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id),
 evaluated_at timestamptz not null default now(), weight_kg numeric(6,2) not null check(weight_kg between 1 and 500),
 height_cm numeric(5,2) not null check(height_cm between 1 and 250), notes text,
 created_by uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table if not exists public.body_measurements (
 id uuid primary key default gen_random_uuid(), assessment_id uuid not null unique references public.assessments(id) on delete cascade,
 waist_cm numeric(6,2), abdomen_cm numeric(6,2), hip_cm numeric(6,2), chest_cm numeric(6,2),
 arm_right_cm numeric(6,2), arm_left_cm numeric(6,2), thigh_right_cm numeric(6,2), thigh_left_cm numeric(6,2),
 calf_right_cm numeric(6,2), calf_left_cm numeric(6,2), created_at timestamptz not null default now()
);
create table if not exists public.body_metrics (
 id uuid primary key default gen_random_uuid(), assessment_id uuid not null unique references public.assessments(id) on delete cascade,
 bmi numeric(6,2), bmr numeric(9,2), tdee numeric(9,2), body_fat_percentage numeric(5,2),
 lean_mass_kg numeric(7,2), fat_mass_kg numeric(7,2), formula_version text not null default '1.0', calculated_at timestamptz not null default now()
);
create table if not exists public.goals (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id),
 goal_type text not null, target_value numeric(10,2), initial_value numeric(10,2), deadline date,
 status text not null default 'active' check(status in ('active','completed','cancelled')), created_at timestamptz not null default now()
);
create table if not exists public.exercises (
 id uuid primary key default gen_random_uuid(), name text not null, muscle_group text not null,
 equipment text, instructions text, image_path text, video_url text, created_at timestamptz not null default now()
);
create table if not exists public.workout_plans (
 id uuid primary key default gen_random_uuid(), name text not null, level text not null check(level in ('beginner','intermediate','advanced')),
 objective text not null, description text, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table if not exists public.workout_days (
 id uuid primary key default gen_random_uuid(), workout_plan_id uuid not null references public.workout_plans(id) on delete cascade,
 day_name text not null, sequence integer not null default 1
);
create table if not exists public.workout_exercises (
 id uuid primary key default gen_random_uuid(), workout_day_id uuid not null references public.workout_days(id) on delete cascade,
 exercise_id uuid not null references public.exercises(id), sets integer not null check(sets between 1 and 20),
 reps_min integer not null check(reps_min between 1 and 100), reps_max integer not null check(reps_max >= reps_min and reps_max <= 100),
 rest_seconds integer not null default 60, sequence integer not null default 1
);
create table if not exists public.workout_assignments (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id),
 workout_plan_id uuid not null references public.workout_plans(id), start_date date not null default current_date,
 end_date date, status text not null default 'active' check(status in ('active','completed','cancelled'))
);
create table if not exists public.workout_logs (
 id uuid primary key default gen_random_uuid(), assignment_id uuid not null references public.workout_assignments(id),
 student_id uuid not null references public.students(id), performed_at timestamptz not null default now(), duration_minutes integer, notes text
);
create table if not exists public.exercise_sets (
 id uuid primary key default gen_random_uuid(), workout_log_id uuid not null references public.workout_logs(id) on delete cascade,
 exercise_id uuid not null references public.exercises(id), set_number integer not null, weight_kg numeric(7,2), repetitions integer, completed boolean not null default false
);
create table if not exists public.nutrition_plans (
 id uuid primary key default gen_random_uuid(), name text not null, objective text not null,
 professional_name text, professional_registration text, notes text, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table if not exists public.nutrition_assignments (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id),
 nutrition_plan_id uuid not null references public.nutrition_plans(id), start_date date not null default current_date,
 end_date date, status text not null default 'active' check(status in ('active','completed','cancelled'))
);
create table if not exists public.meals (
 id uuid primary key default gen_random_uuid(), nutrition_plan_id uuid not null references public.nutrition_plans(id) on delete cascade,
 meal_name text not null, scheduled_time time, sequence integer not null default 1
);
create table if not exists public.food_items (
 id uuid primary key default gen_random_uuid(), name text not null, serving_unit text not null default 'g',
 calories numeric(8,2), protein_g numeric(8,2), carbs_g numeric(8,2), fat_g numeric(8,2)
);
create table if not exists public.meal_items (
 id uuid primary key default gen_random_uuid(), meal_id uuid not null references public.meals(id) on delete cascade,
 food_item_id uuid not null references public.food_items(id), quantity numeric(9,2) not null check(quantity > 0), unit text not null default 'g'
);
create table if not exists public.progress_records (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id),
 record_date date not null default current_date, weight_kg numeric(6,2), notes text, created_at timestamptz not null default now()
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id),
 title text not null, message text not null, read_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
 id uuid primary key default gen_random_uuid(), actor_id uuid references public.profiles(id), action text not null,
 entity_type text not null, entity_id uuid, details jsonb, created_at timestamptz not null default now()
);

create index if not exists idx_students_created_by on public.students(created_by);
create index if not exists idx_assessments_student_date on public.assessments(student_id,evaluated_at desc);
create index if not exists idx_workout_assignment_student on public.workout_assignments(student_id,status);
create index if not exists idx_nutrition_assignment_student on public.nutrition_assignments(student_id,status);
create index if not exists idx_progress_student_date on public.progress_records(student_id,record_date desc);

create or replace function public.current_user_is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;
create or replace function public.current_user_student_id() returns uuid language sql stable security definer set search_path=public as $$ select id from public.students where user_id=auth.uid() limit 1 $$;

-- Profile rows are created automatically. Role is always student until explicitly promoted by trusted SQL.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name,email,role) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),coalesce(new.email,''),'student') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Enable RLS on all user and business tables.
do $$ declare t text; begin foreach t in array array['profiles','students','assessments','body_measurements','body_metrics','goals','exercises','workout_plans','workout_days','workout_exercises','workout_assignments','workout_logs','exercise_sets','nutrition_plans','nutrition_assignments','meals','food_items','meal_items','progress_records','notifications','audit_logs'] loop execute format('alter table public.%I enable row level security',t); end loop; end $$;

-- Profiles: users see their own profile; admin manages profiles. No user can promote their own role.
create policy profiles_read_self_or_admin on public.profiles for select to authenticated using(id=auth.uid() or public.current_user_is_admin());
create policy profiles_update_self_safe on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and role='student');
create policy profiles_admin_all on public.profiles for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());

create policy students_admin_all on public.students for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy students_self_read on public.students for select to authenticated using(user_id=auth.uid());

create policy assessments_admin_all on public.assessments for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy assessments_student_read on public.assessments for select to authenticated using(student_id=public.current_user_student_id());
create policy body_measurements_admin_all on public.body_measurements for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy body_measurements_student_read on public.body_measurements for select to authenticated using(exists(select 1 from public.assessments a where a.id=assessment_id and a.student_id=public.current_user_student_id()));
create policy body_metrics_admin_all on public.body_metrics for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy body_metrics_student_read on public.body_metrics for select to authenticated using(exists(select 1 from public.assessments a where a.id=assessment_id and a.student_id=public.current_user_student_id()));

create policy goals_admin_all on public.goals for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy goals_student_read on public.goals for select to authenticated using(student_id=public.current_user_student_id());
create policy exercises_authenticated_read on public.exercises for select to authenticated using(true);
create policy exercises_admin_write on public.exercises for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy workout_plans_admin_all on public.workout_plans for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy workout_plans_assigned_read on public.workout_plans for select to authenticated using(exists(select 1 from public.workout_assignments wa where wa.workout_plan_id=id and wa.student_id=public.current_user_student_id() and wa.status='active'));
create policy workout_days_admin_all on public.workout_days for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy workout_days_assigned_read on public.workout_days for select to authenticated using(exists(select 1 from public.workout_plans wp join public.workout_assignments wa on wa.workout_plan_id=wp.id where wp.id=workout_plan_id and wa.student_id=public.current_user_student_id() and wa.status='active'));
create policy workout_exercises_admin_all on public.workout_exercises for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy workout_exercises_assigned_read on public.workout_exercises for select to authenticated using(exists(select 1 from public.workout_days wd join public.workout_assignments wa on wa.workout_plan_id=wd.workout_plan_id where wd.id=workout_day_id and wa.student_id=public.current_user_student_id() and wa.status='active'));
create policy workout_assignments_admin_all on public.workout_assignments for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy workout_assignments_student_read on public.workout_assignments for select to authenticated using(student_id=public.current_user_student_id());
create policy workout_logs_admin_all on public.workout_logs for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy workout_logs_student_own on public.workout_logs for all to authenticated using(student_id=public.current_user_student_id()) with check(student_id=public.current_user_student_id() and exists(select 1 from public.workout_assignments wa where wa.id=assignment_id and wa.student_id=public.current_user_student_id()));
create policy exercise_sets_admin_all on public.exercise_sets for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy exercise_sets_student_own on public.exercise_sets for all to authenticated using(exists(select 1 from public.workout_logs wl where wl.id=workout_log_id and wl.student_id=public.current_user_student_id())) with check(exists(select 1 from public.workout_logs wl where wl.id=workout_log_id and wl.student_id=public.current_user_student_id()));

create policy nutrition_plans_admin_all on public.nutrition_plans for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy nutrition_plans_assigned_read on public.nutrition_plans for select to authenticated using(exists(select 1 from public.nutrition_assignments na where na.nutrition_plan_id=id and na.student_id=public.current_user_student_id() and na.status='active'));
create policy nutrition_assignments_admin_all on public.nutrition_assignments for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy nutrition_assignments_student_read on public.nutrition_assignments for select to authenticated using(student_id=public.current_user_student_id());
create policy meals_admin_all on public.meals for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy meals_assigned_read on public.meals for select to authenticated using(exists(select 1 from public.nutrition_assignments na where na.nutrition_plan_id=meals.nutrition_plan_id and na.student_id=public.current_user_student_id() and na.status='active'));
create policy food_items_authenticated_read on public.food_items for select to authenticated using(true);
create policy food_items_admin_write on public.food_items for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy meal_items_admin_all on public.meal_items for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy meal_items_assigned_read on public.meal_items for select to authenticated using(exists(select 1 from public.meals m join public.nutrition_assignments na on na.nutrition_plan_id=m.nutrition_plan_id where m.id=meal_id and na.student_id=public.current_user_student_id() and na.status='active'));
create policy progress_admin_all on public.progress_records for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy progress_student_own on public.progress_records for all to authenticated using(student_id=public.current_user_student_id()) with check(student_id=public.current_user_student_id());
create policy notifications_admin_all on public.notifications for all to authenticated using(public.current_user_is_admin()) with check(public.current_user_is_admin());
create policy notifications_student_own on public.notifications for select to authenticated using(student_id=public.current_user_student_id());
create policy audit_admin_read on public.audit_logs for select to authenticated using(public.current_user_is_admin());

-- IMPORTANT: promote the first trusted account to admin manually after signup:
-- update public.profiles set role='admin' where email='SEU_EMAIL';
