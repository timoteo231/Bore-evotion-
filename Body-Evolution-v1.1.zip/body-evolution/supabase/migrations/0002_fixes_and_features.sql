-- Body Evolution 0002: transações atômicas, auditoria, índices e dados iniciais.
-- Execute DEPOIS da 0001. Seguro para rodar mais de uma vez.

-- E-mail único por aluno (sem diferenciar maiúsculas).
create unique index if not exists students_email_unique on public.students (lower(email));
create index if not exists idx_workout_logs_student_date on public.workout_logs(student_id, performed_at desc);

-- Auditoria: só administradores gravam; ninguém edita nem apaga.
create or replace function public.log_audit(p_action text, p_entity_type text, p_entity_id uuid, p_details jsonb default null)
returns void language sql security definer set search_path = public as $$
  insert into public.audit_logs(actor_id, action, entity_type, entity_id, details)
  select auth.uid(), p_action, p_entity_type, p_entity_id, p_details
  where public.current_user_is_admin()
$$;
revoke all on function public.log_audit(text, text, uuid, jsonb) from public;
grant execute on function public.log_audit(text, text, uuid, jsonb) to authenticated;

-- Avaliação + métricas na mesma transação (security invoker: a RLS continua valendo).
create or replace function public.create_assessment(
  p_student_id uuid, p_weight numeric, p_height numeric, p_notes text,
  p_bmi numeric, p_bmr numeric, p_tdee numeric, p_formula text
) returns uuid language plpgsql security invoker set search_path = public as $$
declare v_id uuid;
begin
  insert into public.assessments(student_id, weight_kg, height_cm, notes, created_by)
  values (p_student_id, p_weight, p_height, p_notes, auth.uid()) returning id into v_id;
  insert into public.body_metrics(assessment_id, bmi, bmr, tdee, formula_version)
  values (v_id, p_bmi, p_bmr, p_tdee, p_formula);
  return v_id;
end $$;

-- Ficha de treino completa (plano > dias > exercícios) em uma transação.
create or replace function public.create_workout_plan(
  p_name text, p_level text, p_objective text, p_description text, p_days jsonb
) returns uuid language plpgsql security invoker set search_path = public as $$
declare v_plan uuid; v_day uuid; d jsonb; e jsonb; di int := 0; ei int;
begin
  insert into public.workout_plans(name, level, objective, description, created_by)
  values (p_name, p_level, p_objective, p_description, auth.uid()) returning id into v_plan;
  for d in select value from jsonb_array_elements(p_days) loop
    di := di + 1;
    insert into public.workout_days(workout_plan_id, day_name, sequence)
    values (v_plan, d->>'day_name', di) returning id into v_day;
    ei := 0;
    for e in select value from jsonb_array_elements(d->'exercises') loop
      ei := ei + 1;
      insert into public.workout_exercises(workout_day_id, exercise_id, sets, reps_min, reps_max, rest_seconds, sequence)
      values (v_day, (e->>'exercise_id')::uuid, (e->>'sets')::int, (e->>'reps_min')::int,
              (e->>'reps_max')::int, coalesce((e->>'rest_seconds')::int, 60), ei);
    end loop;
  end loop;
  return v_plan;
end $$;

-- Plano alimentar completo (plano > refeições > itens) em uma transação.
create or replace function public.create_nutrition_plan(
  p_name text, p_objective text, p_prof_name text, p_prof_reg text, p_notes text, p_meals jsonb
) returns uuid language plpgsql security invoker set search_path = public as $$
declare v_plan uuid; v_meal uuid; m jsonb; it jsonb; mi int := 0;
begin
  insert into public.nutrition_plans(name, objective, professional_name, professional_registration, notes, created_by)
  values (p_name, p_objective, p_prof_name, p_prof_reg, p_notes, auth.uid()) returning id into v_plan;
  for m in select value from jsonb_array_elements(p_meals) loop
    mi := mi + 1;
    insert into public.meals(nutrition_plan_id, meal_name, scheduled_time, sequence)
    values (v_plan, m->>'meal_name', nullif(m->>'scheduled_time', '')::time, mi) returning id into v_meal;
    for it in select value from jsonb_array_elements(m->'items') loop
      insert into public.meal_items(meal_id, food_item_id, quantity, unit)
      values (v_meal, (it->>'food_item_id')::uuid, (it->>'quantity')::numeric, coalesce(nullif(it->>'unit', ''), 'g'));
    end loop;
  end loop;
  return v_plan;
end $$;

-- Treino realizado pelo aluno + séries. O aluno vem do login, nunca do cliente.
create or replace function public.log_workout(p_assignment_id uuid, p_duration int, p_notes text, p_sets jsonb)
returns uuid language plpgsql security invoker set search_path = public as $$
declare v_log uuid; s jsonb;
begin
  insert into public.workout_logs(assignment_id, student_id, duration_minutes, notes)
  values (p_assignment_id, public.current_user_student_id(), p_duration, p_notes) returning id into v_log;
  for s in select value from jsonb_array_elements(p_sets) loop
    insert into public.exercise_sets(workout_log_id, exercise_id, set_number, weight_kg, repetitions, completed)
    values (v_log, (s->>'exercise_id')::uuid, (s->>'set_number')::int,
            nullif(s->>'weight_kg', '')::numeric, nullif(s->>'repetitions', '')::int, true);
  end loop;
  return v_log;
end $$;

-- Dados iniciais (idempotentes).
insert into public.exercises(name, muscle_group, equipment)
select v.name, v.muscle_group, v.equipment from (values
 ('Supino reto','Peito','Barra'),('Supino inclinado com halteres','Peito','Halteres'),('Supino declinado','Peito','Barra'),
 ('Crucifixo','Peito','Halteres'),('Crossover','Peito','Polia'),('Flexão de braço','Peito','Peso corporal'),
 ('Puxada frontal','Costas','Polia'),('Remada curvada','Costas','Barra'),('Remada baixa','Costas','Polia'),
 ('Remada unilateral','Costas','Halteres'),('Barra fixa','Costas','Peso corporal'),('Levantamento terra','Costas','Barra'),
 ('Agachamento livre','Pernas','Barra'),('Leg press','Pernas','Máquina'),('Cadeira extensora','Pernas','Máquina'),
 ('Mesa flexora','Pernas','Máquina'),('Stiff','Pernas','Barra'),('Afundo','Pernas','Halteres'),('Panturrilha em pé','Pernas','Máquina'),
 ('Desenvolvimento com halteres','Ombros','Halteres'),('Elevação lateral','Ombros','Halteres'),('Elevação frontal','Ombros','Halteres'),
 ('Crucifixo inverso','Ombros','Halteres'),('Encolhimento','Ombros','Halteres'),
 ('Rosca direta','Bíceps','Barra'),('Rosca martelo','Bíceps','Halteres'),('Rosca scott','Bíceps','Barra'),
 ('Tríceps na polia','Tríceps','Polia'),('Tríceps testa','Tríceps','Barra'),('Tríceps francês','Tríceps','Halteres'),
 ('Abdominal supra','Abdômen','Peso corporal'),('Prancha','Abdômen','Peso corporal'),('Elevação de pernas','Abdômen','Peso corporal')
) as v(name, muscle_group, equipment)
where not exists (select 1 from public.exercises e where e.name = v.name);

-- Valores aproximados por 100 g/ml (ou por unidade quando serving_unit = 'un'). Conferir com nutricionista.
insert into public.food_items(name, serving_unit, calories, protein_g, carbs_g, fat_g)
select v.name, v.unit, v.kcal, v.p, v.c, v.f from (values
 ('Peito de frango grelhado','g',159,32,0,2.5),('Patinho bovino grelhado','g',219,35.9,0,7.3),('Tilápia grelhada','g',128,26,0,2.7),
 ('Ovo cozido','un',78,6.3,0.6,5.3),('Arroz branco cozido','g',128,2.5,28.1,0.2),('Feijão carioca cozido','g',76,4.8,13.6,0.5),
 ('Batata-doce cozida','g',77,0.6,18.4,0.1),('Macarrão cozido','g',102,3.4,20,0.5),('Aveia em flocos','g',394,13.9,66.6,8.5),
 ('Pão integral','g',253,9.4,49.9,3.7),('Banana prata','g',98,1.3,26,0.1),('Maçã','g',56,0.3,15.2,0),
 ('Leite desnatado','ml',35,3.4,4.9,0.1),('Iogurte natural','g',51,4.1,7,0.1),('Whey protein (1 dose)','un',120,24,3,2),
 ('Pasta de amendoim','g',588,25,20,50),('Azeite de oliva','ml',884,0,0,100),('Brócolis cozido','g',25,2.1,4.4,0.5),('Alface','g',11,1.3,1.7,0.2)
) as v(name, unit, kcal, p, c, f)
where not exists (select 1 from public.food_items x where x.name = v.name);
