import Link from 'next/link';

export const metadata = { title: 'Política de Privacidade — Body Evolution' };

export default function Privacy() {
  return <main className="shell legal" style={{ maxWidth: 780 }}>
    <Link href="/" className="brand">BODY EVOLUTION</Link>
    <h1 style={{ marginTop: 28 }}>Política de Privacidade</h1>
    <p className="danger sm">MODELO INICIAL — revise com um profissional jurídico e preencha os campos entre colchetes antes de usar com alunos reais.</p>
    <h2>1. Quem é o controlador</h2><p>[NOME / RAZÃO SOCIAL], CPF/CNPJ [NÚMERO], contato do encarregado (DPO): [E-MAIL].</p>
    <h2>2. Quais dados tratamos</h2>
    <ul><li>Identificação: nome, e-mail, data de nascimento, sexo.</li><li>Dados de saúde e corporais (sensíveis, art. 11 da LGPD): peso, altura, medidas, IMC, TMB/gasto estimado, histórico de treinos e planos alimentares.</li><li>Dados técnicos de acesso: registros de login e auditoria de ações administrativas.</li></ul>
    <h2>3. Para que usamos</h2><p>Prestar o acompanhamento de treino e nutrição contratado, calcular indicadores de evolução e manter a segurança da conta. Não vendemos dados nem os usamos para publicidade.</p>
    <h2>4. Base legal</h2><p>Consentimento específico do titular para dados de saúde e execução do contrato de acompanhamento. O consentimento pode ser revogado a qualquer momento.</p>
    <h2>5. Compartilhamento</h2><p>Os dados ficam acessíveis ao seu treinador/administrador e a você. Usamos provedores de infraestrutura (Supabase e Vercel) como operadores, sob contrato.</p>
    <h2>6. Seus direitos (art. 18)</h2><p>Confirmação de tratamento, acesso, correção, anonimização, portabilidade, eliminação, informação sobre compartilhamento e revogação do consentimento, solicitados pelo contato acima.</p>
    <h2>7. Retenção e segurança</h2><p>Mantemos os dados enquanto durar o acompanhamento e pelo prazo legal aplicável. Acesso por login individual, políticas de isolamento entre alunos no banco e registro de ações administrativas.</p>
    <p className="muted sm" style={{ marginTop: 30 }}>Última atualização: [DATA]. <Link className="gold" href="/termos">Termos de Uso</Link></p>
  </main>;
}
