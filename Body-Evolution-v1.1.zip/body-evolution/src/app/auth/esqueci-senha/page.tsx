'use client';
import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';

export default function ForgotPassword() {
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const email = String(new FormData(e.currentTarget).get('email'));
    await createClient().auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/auth/confirm?next=/auth/definir-senha` });
    setSent(true); setBusy(false); // Mesma resposta exista ou não a conta (evita enumeração de e-mails).
  }

  return <main className="shell" style={{ maxWidth: 460, paddingTop: 80 }}>
    <Link href="/" className="brand">BODY EVOLUTION</Link>
    <section className="card" style={{ marginTop: 28 }}>
      <h1>Recuperar senha</h1>
      {sent ? <p className="muted">Se o e-mail estiver cadastrado, você receberá um link para criar uma nova senha.</p> :
      <form onSubmit={submit}>
        <label className="field">E-mail<input name="email" type="email" required autoComplete="email" /></label>
        <button className="btn" disabled={busy} style={{ width: '100%' }}>{busy ? 'Enviando...' : 'Enviar link'}</button>
      </form>}
      <p style={{ marginTop: 18 }}><Link className="gold" href="/login">Voltar ao login</Link></p>
    </section></main>;
}
