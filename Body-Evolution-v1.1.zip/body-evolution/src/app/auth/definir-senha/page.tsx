'use client';
import { FormEvent, useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';

export default function SetPassword() {
  const [ready, setReady] = useState<boolean | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    createClient().auth.getUser().then(({ data }) => setReady(!!data.user));
  }, []);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const password = String(f.get('password'));
    if (password.length < 8) return setError('Use pelo menos 8 caracteres.');
    if (password !== String(f.get('confirm'))) return setError('As senhas não conferem.');
    setBusy(true); setError('');
    const { error } = await createClient().auth.updateUser({ password });
    if (error) { setError('Não foi possível salvar a senha. Peça um novo link.'); setBusy(false); return; }
    window.location.href = '/dashboard';
  }

  return <main className="shell" style={{ maxWidth: 460, paddingTop: 80 }}>
    <Link href="/" className="brand">BODY EVOLUTION</Link>
    <section className="card" style={{ marginTop: 28 }}>
      <h1>Definir senha</h1>
      {ready === false ? <p className="muted">Link inválido ou expirado. <Link className="gold" href="/auth/esqueci-senha">Solicitar novo link</Link></p> :
      <form onSubmit={submit}>
        <label className="field">Nova senha<input name="password" type="password" required minLength={8} autoComplete="new-password" /></label>
        <label className="field">Confirmar senha<input name="confirm" type="password" required minLength={8} autoComplete="new-password" /></label>
        {error && <p className="danger">{error}</p>}
        <button className="btn" disabled={busy || ready === null} style={{ width: '100%' }}>{busy ? 'Salvando...' : 'Salvar e entrar'}</button>
      </form>}
    </section></main>;
}
