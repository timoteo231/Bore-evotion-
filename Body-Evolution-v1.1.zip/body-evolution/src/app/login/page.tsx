'use client';
import { FormEvent, useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('erro') === 'link') setError('Link inválido ou expirado. Solicite um novo.');
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    const { error } = await createClient().auth.signInWithPassword({ email, password });
    if (error) { setError('E-mail ou senha incorretos.'); setBusy(false); return; }
    window.location.href = '/dashboard';
  }

  return <main className="shell" style={{ maxWidth: 460, paddingTop: 80 }}>
    <Link href="/" className="brand">BODY EVOLUTION</Link>
    <section className="card" style={{ marginTop: 28 }}>
      <h1>Bem-vindo</h1>
      <p className="muted">Entre na sua conta para acompanhar sua evolução.</p>
      <form onSubmit={submit}>
        <label className="field">E-mail<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></label>
        <label className="field">Senha<input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
        {error && <p className="danger" role="alert">{error}</p>}
        <button className="btn" disabled={busy} style={{ width: '100%' }}>{busy ? 'Entrando...' : 'Entrar'}</button>
      </form>
      <p style={{ marginTop: 18 }}><Link className="gold" href="/auth/esqueci-senha">Esqueci minha senha</Link></p>
    </section></main>;
}
