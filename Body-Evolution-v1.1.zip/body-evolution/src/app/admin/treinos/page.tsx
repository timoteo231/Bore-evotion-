import { requireRole } from '@/lib/auth';
import { fmtDate, levelLabel } from '@/lib/labels';
import AppHeader from '@/components/app-header';
import WorkoutBuilder from '@/components/workout-builder';

export default async function WorkoutsAdmin() {
  const { supabase } = await requireRole('admin');
  const [{ data: exercises }, { data: plans }] = await Promise.all([
    supabase.from('exercises').select('id,name,muscle_group').order('name'),
    supabase.from('workout_plans').select('id,name,level,objective,created_at,workout_days(id)').order('created_at', { ascending: false }),
  ]);
  return <><AppHeader role="admin" /><main className="shell stack">
    <div><span className="badge">TREINOS</span><h1>Fichas de treino</h1></div>
    {(exercises ?? []).length === 0
      ? <section className="card"><p className="danger">A biblioteca de exercícios está vazia. Execute a migração 0002 no Supabase.</p></section>
      : <WorkoutBuilder exercises={exercises ?? []} />}
    <section className="card table-wrap"><h2>Fichas criadas</h2>
      {(plans ?? []).length === 0 ? <p className="muted">Nenhuma ficha ainda.</p> :
      <table className="table"><thead><tr><th>Nome</th><th>Nível</th><th>Objetivo</th><th>Dias</th><th>Criada em</th></tr></thead>
        <tbody>{plans!.map((p) => <tr key={p.id}><td>{p.name}</td><td>{levelLabel[p.level] ?? p.level}</td><td>{p.objective}</td><td>{(p.workout_days as unknown[] | null)?.length ?? 0}</td><td>{fmtDate(p.created_at)}</td></tr>)}</tbody></table>}
    </section></main></>;
}
