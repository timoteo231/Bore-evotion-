import { requireRole } from '@/lib/auth';
import { fmtDate } from '@/lib/labels';
import AppHeader from '@/components/app-header';
import NutritionBuilder from '@/components/nutrition-builder';

export default async function NutritionAdmin() {
  const { supabase } = await requireRole('admin');
  const [{ data: foods }, { data: plans }] = await Promise.all([
    supabase.from('food_items').select('id,name,serving_unit').order('name'),
    supabase.from('nutrition_plans').select('id,name,objective,professional_name,professional_registration,created_at').order('created_at', { ascending: false }),
  ]);
  return <><AppHeader role="admin" /><main className="shell stack">
    <div><span className="badge">DIETAS</span><h1>Planos alimentares</h1></div>
    {(foods ?? []).length === 0
      ? <section className="card"><p className="danger">A tabela de alimentos está vazia. Execute a migração 0002 no Supabase.</p></section>
      : <NutritionBuilder foods={foods ?? []} />}
    <section className="card table-wrap"><h2>Planos criados</h2>
      {(plans ?? []).length === 0 ? <p className="muted">Nenhum plano ainda.</p> :
      <table className="table"><thead><tr><th>Nome</th><th>Objetivo</th><th>Responsável</th><th>Criado em</th></tr></thead>
        <tbody>{plans!.map((p) => <tr key={p.id}><td>{p.name}</td><td>{p.objective}</td><td>{p.professional_name} ({p.professional_registration})</td><td>{fmtDate(p.created_at)}</td></tr>)}</tbody></table>}
    </section></main></>;
}
