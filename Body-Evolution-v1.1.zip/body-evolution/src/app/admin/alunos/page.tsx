import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { objectiveLabel, statusLabel } from '@/lib/labels';
import AppHeader from '@/components/app-header';
import StudentForm from '@/components/student-form';
import AssessmentForm from '@/components/assessment-form';

export default async function StudentsPage() {
  const { supabase } = await requireRole('admin');
  const { data: students, error } = await supabase.from('students')
    .select('id,full_name,email,objective,status,user_id,created_at').order('created_at', { ascending: false });
  const active = (students ?? []).filter((s) => s.status === 'active').length;
  const withAccess = (students ?? []).filter((s) => s.user_id).length;

  return <><AppHeader role="admin" /><main className="shell stack">
    <div><span className="badge">PAINEL ADMINISTRATIVO</span><h1>Alunos</h1><p className="muted">Cadastre alunos, envie convites e acompanhe a evolução.</p></div>
    <div className="grid">
      <div className="card"><div className="muted">Alunos ativos</div><div className="stat">{active}</div></div>
      <div className="card"><div className="muted">Com acesso ao app</div><div className="stat">{withAccess}</div></div>
      <div className="card"><div className="muted">Banco de dados</div><div className="stat" style={{ fontSize: 20 }}>{error ? 'Verificar conexão' : 'Conectado'}</div></div>
    </div>
    <StudentForm />
    <AssessmentForm students={(students ?? []).filter((s) => s.status === 'active').map((s) => ({ id: s.id, full_name: s.full_name }))} />
    <section className="card table-wrap"><h2>Lista de alunos</h2>
      {error ? <p className="danger">Não foi possível carregar os alunos.</p> :
      <table className="table"><thead><tr><th>Nome</th><th>E-mail</th><th>Objetivo</th><th>Acesso</th><th>Status</th></tr></thead>
        <tbody>{students?.map((s) => <tr key={s.id}>
          <td><Link className="gold" href={`/admin/alunos/${s.id}`}>{s.full_name}</Link></td><td>{s.email}</td>
          <td>{objectiveLabel[s.objective] ?? s.objective}</td><td>{s.user_id ? 'Vinculado' : 'Sem convite'}</td>
          <td><span className="badge">{statusLabel[s.status] ?? s.status}</span></td></tr>)}</tbody></table>}
    </section></main></>;
}
