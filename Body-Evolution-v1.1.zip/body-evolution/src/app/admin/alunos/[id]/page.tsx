import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireRole } from '@/lib/auth';
import { fmtDate, objectiveLabel, statusLabel } from '@/lib/labels';
import AppHeader from '@/components/app-header';
import StudentActions from '@/components/student-actions';
import AssignPlan from '@/components/assign-plan';
import AssessmentForm from '@/components/assessment-form';
import WeightChart from '@/components/weight-chart';

type Metrics = { bmi: number | null; bmr: number | null; tdee: number | null };
const one = <T,>(x: T | T[] | null | undefined): T | null => (Array.isArray(x) ? x[0] ?? null : x ?? null);

export default async function StudentDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await requireRole('admin');
  const { data: student } = await supabase.from('students')
    .select('id,full_name,email,birth_date,sex,height_cm,objective,status,user_id,start_date').eq('id', id).maybeSingle();
  if (!student) notFound();

  const [assessments, workout, nutrition, wPlans, nPlans] = await Promise.all([
    supabase.from('assessments').select('id,evaluated_at,weight_kg,height_cm,notes,body_metrics(bmi,bmr,tdee)').eq('student_id', id).order('evaluated_at', { ascending: true }),
    supabase.from('workout_assignments').select('id,start_date,workout_plans(name)').eq('student_id', id).eq('status', 'active').maybeSingle(),
    supabase.from('nutrition_assignments').select('id,start_date,nutrition_plans(name)').eq('student_id', id).eq('status', 'active').maybeSingle(),
    supabase.from('workout_plans').select('id,name').order('created_at', { ascending: false }),
    supabase.from('nutrition_plans').select('id,name').order('created_at', { ascending: false }),
  ]);
  const list = assessments.data ?? [];
  const chart = list.map((a) => ({ date: new Date(a.evaluated_at).toLocaleDateString('pt-BR'), peso: Number(a.weight_kg) }));
  const planName = (x: unknown) => (one(x as { name: string } | { name: string }[] | null)?.name ?? '—');

  return <><AppHeader role="admin" /><main className="shell stack">
    <div><Link className="muted" href="/admin/alunos">← Alunos</Link>
      <h1>{student.full_name}</h1>
      <p className="muted">{student.email} · {objectiveLabel[student.objective] ?? student.objective} · <span className="badge">{statusLabel[student.status]}</span> · {student.user_id ? 'Acesso vinculado' : 'Sem acesso ao app'}</p></div>
    <section className="card"><h2>Acesso e status</h2><StudentActions studentId={student.id} hasAccount={!!student.user_id} status={student.status} /></section>
    <div className="grid">
      <section className="card"><h2>Ficha de treino</h2><p className="muted">Atual: {workout.data ? planName((workout.data as { workout_plans: unknown }).workout_plans) : 'nenhuma'}</p>
        <AssignPlan kind="workout" studentId={student.id} plans={wPlans.data ?? []} /></section>
      <section className="card"><h2>Plano alimentar</h2><p className="muted">Atual: {nutrition.data ? planName((nutrition.data as { nutrition_plans: unknown }).nutrition_plans) : 'nenhum'}</p>
        <AssignPlan kind="nutrition" studentId={student.id} plans={nPlans.data ?? []} /></section>
    </div>
    <section className="card"><h2>Evolução do peso</h2><WeightChart data={chart} /></section>
    <AssessmentForm students={[{ id: student.id, full_name: student.full_name }]} defaultStudentId={student.id} defaultHeight={student.height_cm} />
    <section className="card table-wrap"><h2>Avaliações</h2>
      {list.length === 0 ? <p className="muted">Nenhuma avaliação registrada.</p> :
      <table className="table"><thead><tr><th>Data</th><th>Peso</th><th>Altura</th><th>IMC</th><th>TMB</th><th>Gasto</th></tr></thead>
        <tbody>{[...list].reverse().map((a) => { const m = one(a.body_metrics as Metrics | Metrics[] | null); return <tr key={a.id}>
          <td>{fmtDate(a.evaluated_at)}</td><td>{a.weight_kg} kg</td><td>{a.height_cm} cm</td><td>{m?.bmi ?? '—'}</td><td>{m?.bmr ?? '—'}</td><td>{m?.tdee ?? '—'}</td></tr>; })}</tbody></table>}
    </section></main></>;
}
