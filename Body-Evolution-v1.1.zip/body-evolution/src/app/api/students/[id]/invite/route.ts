import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { createAdminClient } from '@/lib/supabase/admin';
import { z } from 'zod';

// Envia o convite por e-mail e vincula o login ao cadastro do aluno.
export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    if (!z.uuid().safeParse(id).success) return errorJson('Aluno inválido.', 400);
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;

    const { data: student } = await auth.supabase.from('students').select('id,full_name,email,user_id,status').eq('id', id).maybeSingle();
    if (!student) return errorJson('Aluno não encontrado.', 404);
    if (student.user_id) return errorJson('Este aluno já tem acesso vinculado.', 409);
    if (student.status !== 'active') return errorJson('Ative o aluno antes de convidar.', 400);

    const admin = createAdminClient();
    const base = process.env.NEXT_PUBLIC_APP_URL || new URL(_request.url).origin;
    let userId: string | null = null;

    const { data: invited, error } = await admin.auth.admin.inviteUserByEmail(student.email, {
      data: { full_name: student.full_name },
      redirectTo: `${base}/auth/confirm?next=/auth/definir-senha`,
    });
    if (invited?.user) userId = invited.user.id;
    else if (error && /already|registered|exists/i.test(error.message)) {
      // E-mail já existe no Auth: reaproveita o usuário (nunca o de um administrador).
      const { data: list, error: listError } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      if (listError) throw listError;
      const found = list.users.find((u) => u.email?.toLowerCase() === student.email.toLowerCase());
      if (!found) return errorJson('Não foi possível localizar o usuário deste e-mail.', 404);
      const { data: p } = await admin.from('profiles').select('role').eq('id', found.id).single();
      if (p?.role !== 'student') return errorJson('Este e-mail pertence a uma conta não-aluno.', 409);
      userId = found.id;
    } else if (error) throw error;

    const { error: linkError } = await admin.from('students').update({ user_id: userId }).eq('id', id).is('user_id', null);
    if (linkError) {
      if (linkError.code === '23505') return errorJson('Este usuário já está vinculado a outro aluno.', 409);
      throw linkError;
    }
    await audit(auth.supabase, 'student.invite', 'student', id);
    return json({ success: true, message: invited?.user ? 'Convite enviado por e-mail.' : 'Usuário existente vinculado ao aluno.' });
  } catch (e) { return serverError(e); }
}
