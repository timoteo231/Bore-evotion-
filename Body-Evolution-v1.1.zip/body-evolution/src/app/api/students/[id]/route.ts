import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { studentUpdateSchema } from '@/lib/validations/student';
import { z } from 'zod';

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    if (!z.uuid().safeParse(id).success) return errorJson('Aluno inválido.', 400);
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;
    const parsed = studentUpdateSchema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400, parsed.error.flatten());
    const { data, error } = await auth.supabase.from('students').update(parsed.data).eq('id', id).select('id,status').maybeSingle();
    if (error) throw error;
    if (!data) return errorJson('Aluno não encontrado.', 404);
    await audit(auth.supabase, 'student.update', 'student', id, parsed.data);
    return json({ success: true, data });
  } catch (e) { return serverError(e); }
}
