import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { studentSchema } from '@/lib/validations/student';

export async function POST(request: Request) {
  try {
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;
    const { supabase, user } = auth;
    const parsed = studentSchema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400, parsed.error.flatten());
    const { data, error } = await supabase.from('students')
      .insert({ ...parsed.data, created_by: user.id, email: parsed.data.email.toLowerCase() })
      .select('id,full_name,email').single();
    if (error) {
      if (error.code === '23505') return errorJson('Já existe um aluno com este e-mail.', 409);
      throw error;
    }
    await audit(supabase, 'student.create', 'student', data.id);
    return json({ success: true, data, message: 'Aluno cadastrado.' }, 201);
  } catch (e) { return serverError(e); }
}
