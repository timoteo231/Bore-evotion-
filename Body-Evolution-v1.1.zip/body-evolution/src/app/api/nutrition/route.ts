import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { nutritionSchema } from '@/lib/validations/nutrition';

export async function POST(request: Request) {
  try {
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;
    const parsed = nutritionSchema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400, parsed.error.flatten());
    const d = parsed.data;
    const { data: id, error } = await auth.supabase.rpc('create_nutrition_plan', {
      p_name: d.name, p_objective: d.objective, p_prof_name: d.professional_name,
      p_prof_reg: d.professional_registration, p_notes: d.notes || null, p_meals: d.meals,
    });
    if (error) throw error;
    await audit(auth.supabase, 'nutrition_plan.create', 'nutrition_plan', id as string);
    return json({ success: true, data: { id }, message: 'Plano alimentar criado.' }, 201);
  } catch (e) { return serverError(e); }
}
