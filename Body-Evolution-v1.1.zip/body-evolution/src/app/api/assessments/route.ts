import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { computeBodyMetrics } from '@/lib/calculations';
import { z } from 'zod';

const schema = z.object({
  student_id: z.uuid(),
  weight_kg: z.coerce.number().positive().max(500),
  height_cm: z.coerce.number().positive().max(250),
  notes: z.string().max(2000).optional(),
  activity_factor: z.coerce.number().min(1.2).max(1.9).default(1.55),
});

export async function POST(request: Request) {
  try {
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;
    const { supabase } = auth;
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400, parsed.error.flatten());
    const d = parsed.data;

    const { data: student } = await supabase.from('students').select('id,birth_date,sex').eq('id', d.student_id).maybeSingle();
    if (!student) return errorJson('Aluno não encontrado.', 404);

    const m = computeBodyMetrics({ weightKg: d.weight_kg, heightCm: d.height_cm, birthDate: student.birth_date, sex: student.sex, activityFactor: d.activity_factor });
    // Uma única transação no banco: avaliação e métricas gravam juntas ou nenhuma grava.
    const { data: id, error } = await supabase.rpc('create_assessment', {
      p_student_id: d.student_id, p_weight: d.weight_kg, p_height: d.height_cm, p_notes: d.notes || null,
      p_bmi: m.bmi, p_bmr: m.bmr, p_tdee: m.tdee, p_formula: 'v2-mifflin',
    });
    if (error) throw error;
    await audit(supabase, 'assessment.create', 'assessment', id as string);
    return json({ success: true, data: { id, bmi: m.bmi, bmi_category: m.category, bmr: m.bmr, tdee: m.tdee }, message: 'Avaliação registrada.' }, 201);
  } catch (e) { return serverError(e); }
}
