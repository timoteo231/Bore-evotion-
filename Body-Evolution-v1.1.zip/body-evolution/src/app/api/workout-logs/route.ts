import { errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { workoutLogSchema } from '@/lib/validations/workout';

export async function POST(request: Request) {
  try {
    const auth = await requireApiRole('student');
    if ('error' in auth) return auth.error;
    const parsed = workoutLogSchema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400, parsed.error.flatten());
    const d = parsed.data;
    // A RLS garante que a ficha e o registro pertencem ao aluno logado.
    const { data: id, error } = await auth.supabase.rpc('log_workout', {
      p_assignment_id: d.assignment_id, p_duration: d.duration_minutes ?? null, p_notes: d.notes || null, p_sets: d.sets,
    });
    if (error) return errorJson('Não foi possível salvar o treino.', 400);
    return json({ success: true, data: { id }, message: 'Treino salvo.' }, 201);
  } catch (e) { return serverError(e); }
}
