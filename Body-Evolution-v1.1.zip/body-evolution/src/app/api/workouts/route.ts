import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { workoutSchema } from '@/lib/validations/workout';

export async function POST(request: Request) {
  try {
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;
    const parsed = workoutSchema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400, parsed.error.flatten());
    const d = parsed.data;
    const { data: id, error } = await auth.supabase.rpc('create_workout_plan', {
      p_name: d.name, p_level: d.level, p_objective: d.objective, p_description: d.description || null, p_days: d.days,
    });
    if (error) throw error;
    await audit(auth.supabase, 'workout_plan.create', 'workout_plan', id as string);
    return json({ success: true, data: { id }, message: 'Ficha criada.' }, 201);
  } catch (e) { return serverError(e); }
}
