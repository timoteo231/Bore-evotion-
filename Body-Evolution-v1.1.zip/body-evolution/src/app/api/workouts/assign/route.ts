import { audit, errorJson, json, requireApiRole, serverError } from '@/lib/api';
import { assignSchema } from '@/lib/validations/workout';

export async function POST(request: Request) {
  try {
    const auth = await requireApiRole('admin');
    if ('error' in auth) return auth.error;
    const parsed = assignSchema.safeParse(await request.json());
    if (!parsed.success) return errorJson('Dados inválidos.', 400);
    const { student_id, plan_id } = parsed.data;
    const { supabase } = auth;
    const { data: created, error } = await supabase.from('workout_assignments')
      .insert({ student_id, workout_plan_id: plan_id }).select('id').single();
    if (error) throw error;
    // Encerra as fichas anteriores só depois de criar a nova.
    await supabase.from('workout_assignments').update({ status: 'completed', end_date: new Date().toISOString().slice(0, 10) })
      .eq('student_id', student_id).eq('status', 'active').neq('id', created.id);
    await audit(supabase, 'workout.assign', 'workout_assignment', created.id, { student_id, plan_id });
    return json({ success: true, message: 'Ficha atribuída.' }, 201);
  } catch (e) { return serverError(e); }
}
