import { requireRole } from '@/lib/auth';
import { itemMacros, r1, sumMacros, type Food } from '@/lib/nutrition';
import AppHeader from '@/components/app-header';

type Item = { id: string; quantity: number; unit: string; food_items: (Food & { name: string }) | (Food & { name: string })[] | null };
type Meal = { id: string; meal_name: string; scheduled_time: string | null; sequence: number; meal_items: Item[] };
type Plan = { name: string; objective: string; professional_name: string | null; professional_registration: string | null; notes: string | null; meals: Meal[] };

export default async function StudentDiet() {
  const { supabase, user } = await requireRole('student');
  const { data: student } = await supabase.from('students').select('id').eq('user_id', user.id).maybeSingle();
  const { data: assignment } = student ? await supabase.from('nutrition_assignments')
    .select('id,nutrition_plans(name,objective,professional_name,professional_registration,notes,meals(id,meal_name,scheduled_time,sequence,meal_items(id,quantity,unit,food_items(name,serving_unit,calories,protein_g,carbs_g,fat_g))))')
    .eq('student_id', student.id).eq('status', 'active').order('start_date', { ascending: false }).limit(1).maybeSingle() : { data: null };

  const raw = assignment?.nutrition_plans as unknown;
  const plan = (Array.isArray(raw) ? raw[0] : raw) as Plan | null;
  const meals = (plan?.meals ?? []).slice().sort((a, b) => a.sequence - b.sequence).map((m) => {
    const items = m.meal_items.map((it) => {
      const food = Array.isArray(it.food_items) ? it.food_items[0] : it.food_items;
      return { id: it.id, name: food?.name ?? 'Alimento', quantity: it.quantity, unit: it.unit, macros: food ? itemMacros(food, Number(it.quantity)) : { kcal: 0, p: 0, c: 0, f: 0 } };
    });
    return { ...m, items, total: sumMacros(items.map((i) => i.macros)) };
  });
  const day = sumMacros(meals.map((m) => m.total));

  return <><AppHeader role="student" /><main className="shell stack">
    <div><span className="badge">DIETA</span><h1>{plan?.name ?? 'Minha dieta'}</h1></div>
    {!plan ? <section className="card"><p className="muted">Você ainda não tem um plano alimentar ativo.</p></section> : <>
      <div className="grid">
        <div className="card"><div className="muted">Calorias do plano</div><div className="stat">{Math.round(day.kcal)}</div></div>
        <div className="card"><div className="muted">Proteína</div><div className="stat">{r1(day.p)} g</div></div>
        <div className="card"><div className="muted">Carboidrato</div><div className="stat">{r1(day.c)} g</div></div>
        <div className="card"><div className="muted">Gordura</div><div className="stat">{r1(day.f)} g</div></div>
      </div>
      {meals.map((m) => <section className="card" key={m.id}>
        <div className="row" style={{ justifyContent: 'space-between' }}><h2 style={{ margin: 0 }}>{m.meal_name}{m.scheduled_time ? ` · ${m.scheduled_time.slice(0, 5)}` : ''}</h2><span className="muted">{Math.round(m.total.kcal)} kcal</span></div>
        <ul style={{ paddingLeft: 18 }}>{m.items.map((i) => <li key={i.id}>{i.name} — {i.quantity} {i.unit} <span className="muted sm">({Math.round(i.macros.kcal)} kcal)</span></li>)}</ul>
      </section>)}
      <section className="card"><p className="muted sm">Plano elaborado por {plan.professional_name} ({plan.professional_registration}).{plan.notes ? ` ${plan.notes}` : ''} Valores nutricionais são aproximados; siga a orientação do profissional responsável.</p></section></>}
  </main></>;
}
