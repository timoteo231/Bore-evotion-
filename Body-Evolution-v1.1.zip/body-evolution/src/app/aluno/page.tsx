import Link from 'next/link';
import { requireRole } from '@/lib/auth';
import { calculateBMI } from '@/lib/calculations';
import { fmtDate, objectiveLabel } from '@/lib/labels';
import AppHeader from '@/components/app-header';
import WeightChart from '@/components/weight-chart';
import WeightForm from '@/components/weight-form';

type Metrics = { bmi: number | null; bmr: number | null; tdee: number | null };
const one = <T,>(x: T | T[] | null | undefined): T | null => (Array.isArray(x) ? x[0] ?? null : x ?? null);

export default async function StudentHome() {
  const { supabase, user, name } = await requireRole('student');
  const { data: student } = await supabase.from('students').select('id,full_name,objective,height_cm').eq('user_id', user.id).maybeSingle();

  if (!student) return <><AppHeader role="student" /><main className="shell"><section className="card">
    <h1>Olá, {name || 'aluno'}!</h1><p className="muted">Seu acesso ainda não foi vinculado a um cadastro. Fale com seu treinador.</p></section></main></>;

  const [{ data: assessments }, { data: records }] = await Promise.all([
    supabase.from('assessments').select('evaluated_at,weight_kg,height_cm,body_metrics(bmi,bmr,tdee)').eq('student_id', student.id).order('evaluated_at', { ascending: true }),
    supabase.from('progress_records').select('record_date,weight_kg').eq('student_id', student.id).not('weight_kg', 'is', null).order('record_date', { ascending: true }),
  ]);
  const points = [
    ...(assessments ?? []).map((a) => ({ t: new Date(a.evaluated_at).getTime(), peso: Number(a.weight_kg) })),
    ...(records ?? []).map((r) => ({ t: new Date(r.record_date + 'T12:00:00').getTime(), peso: Number(r.weight_kg) })),
  ].sort((a, b) => a.t - b.t);
  const chart = points.map((p) => ({ date: new Date(p.t).toLocaleDateString('pt-BR'), peso: p.peso }));
  const last = (assessments ?? []).at(-1);
  const m = one((last?.body_metrics ?? null) as Metrics | Metrics[] | null);
  const height = last?.height_cm ?? student.height_cm;
  const latestWeight = points.at(-1)?.peso;
  const bmi = m?.bmi ?? (latestWeight && height ? calculateBMI(latestWeight, Number(height)).bmi : null);

  return <><AppHeader role="student" /><main className="shell stack">
    <div><span className="badge">ÁREA DO ALUNO</span><h1>Olá, {student.full_name.split(' ')[0]}!</h1>
      <p className="muted">Objetivo: {objectiveLabel[student.objective] ?? student.objective}</p></div>
    <div className="grid">
      <section className="card"><div className="muted">Último peso</div><div className="stat">{latestWeight ? `${latestWeight} kg` : '—'}</div></section>
      <section className="card"><div className="muted">IMC</div><div className="stat">{bmi ? String(bmi).replace('.', ',') : '—'}</div><div className="muted sm">Triagem; não separa massa muscular de gordura.</div></section>
      <section className="card"><div className="muted">Gasto diário estimado</div><div className="stat">{m?.tdee ? `${m.tdee} kcal` : '—'}</div><div className="muted sm">{last ? `Avaliação de ${fmtDate(last.evaluated_at)}` : 'Aguardando avaliação'}</div></section>
    </div>
    <section className="card"><h2>Evolução do peso</h2><WeightChart data={chart} /><div style={{ marginTop: 14 }}><WeightForm studentId={student.id} /></div></section>
    <div className="grid">
      <Link href="/aluno/treino" className="card"><h2>Meu treino</h2><p className="muted">Ver a ficha e registrar séries.</p></Link>
      <Link href="/aluno/dieta" className="card"><h2>Minha dieta</h2><p className="muted">Ver refeições e macros do plano.</p></Link>
    </div></main></>;
}
