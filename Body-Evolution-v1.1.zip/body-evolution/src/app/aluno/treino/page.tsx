import { requireRole } from '@/lib/auth';
import { fmtDate } from '@/lib/labels';
import AppHeader from '@/components/app-header';
import WorkoutLogger, { type PlanDay } from '@/components/workout-logger';

type RawEx = { id: string; exercise_id: string; sets: number; reps_min: number; reps_max: number; rest_seconds: number; sequence: number; exercises: { name: string } | { name: string }[] | null };
type RawDay = { id: string; day_name: string; sequence: number; workout_exercises: RawEx[] };

export default async function StudentWorkout() {
  const { supabase, user } = await requireRole('student');
  const { data: student } = await supabase.from('students').select('id').eq('user_id', user.id).maybeSingle();
  const { data: assignment } = student ? await supabase.from('workout_assignments')
    .select('id,start_date,workout_plans(name,description,workout_days(id,day_name,sequence,workout_exercises(id,exercise_id,sets,reps_min,reps_max,rest_seconds,sequence,exercises(name))))')
    .eq('student_id', student.id).eq('status', 'active').order('start_date', { ascending: false }).limit(1).maybeSingle() : { data: null };

  const rawPlan = assignment?.workout_plans as unknown;
  const plan = (Array.isArray(rawPlan) ? rawPlan[0] : rawPlan) as { name: string; description: string | null; workout_days: RawDay[] } | null;
  const days: PlanDay[] = (plan?.workout_days ?? []).slice().sort((a, b) => a.sequence - b.sequence).map((d) => ({
    id: d.id, day_name: d.day_name,
    exercises: d.workout_exercises.slice().sort((a, b) => a.sequence - b.sequence).map((e) => ({
      id: e.id, exercise_id: e.exercise_id, sets: e.sets, reps_min: e.reps_min, reps_max: e.reps_max, rest_seconds: e.rest_seconds,
      name: (Array.isArray(e.exercises) ? e.exercises[0]?.name : e.exercises?.name) ?? 'Exercício',
    })),
  }));

  const { data: history } = student ? await supabase.from('workout_logs').select('id,performed_at,duration_minutes,exercise_sets(id)')
    .eq('student_id', student.id).order('performed_at', { ascending: false }).limit(6) : { data: [] };

  return <><AppHeader role="student" /><main className="shell stack">
    <div><span className="badge">TREINO</span><h1>{plan?.name ?? 'Meu treino'}</h1>{plan?.description && <p className="muted">{plan.description}</p>}</div>
    {!assignment || !plan ? <section className="card"><p className="muted">Você ainda não tem uma ficha ativa. Seu treinador vai atribuir uma em breve.</p></section> :
      <section className="card"><WorkoutLogger assignmentId={assignment.id} days={days} /></section>}
    <section className="card"><h2>Últimos treinos</h2>
      {(history ?? []).length === 0 ? <p className="muted">Nenhum treino registrado ainda.</p> :
      <table className="table"><thead><tr><th>Data</th><th>Séries</th><th>Duração</th></tr></thead>
        <tbody>{history!.map((h) => <tr key={h.id}><td>{fmtDate(h.performed_at)}</td><td>{(h.exercise_sets as unknown[] | null)?.length ?? 0}</td><td>{h.duration_minutes ? `${h.duration_minutes} min` : '—'}</td></tr>)}</tbody></table>}
    </section></main></>;
}
