import Link from 'next/link';

export const metadata = { title: 'Termos de Uso — Body Evolution' };

export default function Terms() {
  return <main className="shell legal" style={{ maxWidth: 780 }}>
    <Link href="/" className="brand">BODY EVOLUTION</Link>
    <h1 style={{ marginTop: 28 }}>Termos de Uso</h1>
    <p className="danger sm">MODELO INICIAL — revise com um profissional jurídico antes de usar com alunos reais.</p>
    <h2>1. Finalidade</h2><p>O Body Evolution é uma plataforma privada para registrar treinos, avaliações e planos alimentares fornecidos pelo seu treinador.</p>
    <h2>2. Não substitui orientação profissional</h2><p>Indicadores como IMC, TMB e gasto diário são estimativas e não constituem diagnóstico. Planos alimentares devem ser elaborados ou validados por nutricionista habilitado. Consulte um médico antes de iniciar atividade física intensa.</p>
    <h2>3. Sua conta</h2><p>O acesso é pessoal e intransferível. Mantenha sua senha em sigilo e avise imediatamente em caso de uso indevido.</p>
    <h2>4. Uso adequado</h2><p>É proibido tentar acessar dados de outros alunos, ou usar a plataforma para fins ilícitos.</p>
    <h2>5. Contato</h2><p>[E-MAIL DE SUPORTE]. Veja também a <Link className="gold" href="/privacidade">Política de Privacidade</Link>.</p>
  </main>;
}
