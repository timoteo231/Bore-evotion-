import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export type Role = 'admin' | 'student';

export async function getContext() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { supabase, user: null, role: null as Role | null, name: '' };
  const { data: profile } = await supabase.from('profiles').select('role,full_name').eq('id', user.id).single();
  return { supabase, user, role: (profile?.role ?? null) as Role | null, name: (profile?.full_name ?? '') as string };
}

// Para páginas (server components): redireciona quem não tem acesso.
export async function requireRole(role: Role) {
  const ctx = await getContext();
  if (!ctx.user) redirect('/login');
  if (ctx.role !== role) redirect(ctx.role === 'admin' ? '/admin/alunos' : '/aluno');
  return { ...ctx, user: ctx.user };
}
