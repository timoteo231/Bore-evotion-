export type Food = { serving_unit: string; calories: number | null; protein_g: number | null; carbs_g: number | null; fat_g: number | null };
export type Macros = { kcal: number; p: number; c: number; f: number };

// Alimentos em 'g' ou 'ml' têm valores por 100; em 'un', por unidade.
export function itemMacros(food: Food, quantity: number): Macros {
  const factor = food.serving_unit === 'g' || food.serving_unit === 'ml' ? quantity / 100 : quantity;
  const n = (v: number | null) => (Number(v) || 0) * factor;
  return { kcal: n(food.calories), p: n(food.protein_g), c: n(food.carbs_g), f: n(food.fat_g) };
}
export function sumMacros(list: Macros[]): Macros {
  return list.reduce((a, x) => ({ kcal: a.kcal + x.kcal, p: a.p + x.p, c: a.c + x.c, f: a.f + x.f }), { kcal: 0, p: 0, c: 0, f: 0 });
}
export const r1 = (n: number) => Math.round(n * 10) / 10;
