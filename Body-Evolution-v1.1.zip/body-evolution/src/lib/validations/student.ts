import { z } from 'zod';

const sex = z.enum(['male', 'female', 'other', 'not_informed']);
const objective = z.enum(['hypertrophy', 'weight_loss', 'conditioning', 'maintenance']);

export const studentSchema = z.object({
  full_name: z.string().trim().min(2).max(120),
  email: z.email(),
  birth_date: z.union([z.iso.date(), z.literal('')]).optional(),
  height_cm: z.union([z.coerce.number().positive().max(250), z.literal('')]).optional(),
  sex: sex.default('not_informed'),
  objective: objective.default('hypertrophy'),
}).transform((v) => ({ ...v, birth_date: v.birth_date || null, height_cm: v.height_cm === '' ? null : v.height_cm }));

export const studentUpdateSchema = z.object({
  full_name: z.string().trim().min(2).max(120).optional(),
  objective: objective.optional(),
  status: z.enum(['active', 'inactive']).optional(),
}).refine((v) => Object.keys(v).length > 0, { message: 'Nada para atualizar.' });
