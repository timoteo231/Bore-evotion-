import { z } from 'zod';

const exercise = z.object({
  exercise_id: z.uuid(),
  sets: z.coerce.number().int().min(1).max(20),
  reps_min: z.coerce.number().int().min(1).max(100),
  reps_max: z.coerce.number().int().min(1).max(100),
  rest_seconds: z.coerce.number().int().min(0).max(600),
}).refine((e) => e.reps_max >= e.reps_min, { message: 'Repetições máximas devem ser ≥ mínimas.' });

export const workoutSchema = z.object({
  name: z.string().trim().min(2).max(120),
  level: z.enum(['beginner', 'intermediate', 'advanced']),
  objective: z.string().trim().min(2).max(120),
  description: z.string().trim().max(1000).optional(),
  days: z.array(z.object({ day_name: z.string().trim().min(1).max(80), exercises: z.array(exercise).min(1).max(20) })).min(1).max(7),
});

export const workoutLogSchema = z.object({
  assignment_id: z.uuid(),
  duration_minutes: z.coerce.number().int().min(1).max(600).optional(),
  notes: z.string().trim().max(1000).optional(),
  sets: z.array(z.object({
    exercise_id: z.uuid(),
    set_number: z.coerce.number().int().min(1).max(50),
    weight_kg: z.coerce.number().min(0).max(1000).nullable().optional(),
    repetitions: z.coerce.number().int().min(1).max(200),
  })).min(1).max(300),
});

export const assignSchema = z.object({ student_id: z.uuid(), plan_id: z.uuid() });
