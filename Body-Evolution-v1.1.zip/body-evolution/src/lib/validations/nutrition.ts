import { z } from 'zod';

export const nutritionSchema = z.object({
  name: z.string().trim().min(2).max(120),
  objective: z.string().trim().min(2).max(120),
  professional_name: z.string().trim().min(2).max(120),
  professional_registration: z.string().trim().min(2).max(60),
  notes: z.string().trim().max(2000).optional(),
  meals: z.array(z.object({
    meal_name: z.string().trim().min(1).max(80),
    scheduled_time: z.union([z.string().regex(/^\d{2}:\d{2}$/), z.literal('')]).optional(),
    items: z.array(z.object({
      food_item_id: z.uuid(),
      quantity: z.coerce.number().positive().max(5000),
      unit: z.string().trim().max(10).optional(),
    })).min(1).max(30),
  })).min(1).max(10),
});
