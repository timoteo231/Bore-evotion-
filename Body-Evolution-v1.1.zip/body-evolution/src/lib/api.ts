import { NextResponse } from 'next/server';
import type { SupabaseClient } from '@supabase/supabase-js';
import { createClient } from '@/lib/supabase/server';

export const json = (body: unknown, status = 200) => NextResponse.json(body, { status });
export const errorJson = (message: string, status = 400, details?: unknown) =>
  NextResponse.json({ error: { message, details } }, { status });

// Uso: const auth = await requireApiRole('admin'); if ('error' in auth) return auth.error;
export async function requireApiRole(role: 'admin' | 'student') {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: errorJson('Não autenticado.', 401) } as const;
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== role) return { error: errorJson('Acesso não autorizado.', 403) } as const;
  return { supabase, user } as const;
}

// Detalhes do banco ficam no log do servidor; o cliente recebe só uma mensagem genérica.
export function serverError(e: unknown) {
  console.error(e);
  return errorJson('Erro interno. Tente novamente em instantes.', 500);
}

export async function audit(supabase: SupabaseClient, action: string, entity: string, id: string | null, details?: Record<string, unknown>) {
  const { error } = await supabase.rpc('log_audit', { p_action: action, p_entity_type: entity, p_entity_id: id, p_details: details ?? null });
  if (error) console.error('audit', error.message);
}
