export function calculateBMI(weightKg: number, heightCm: number) {
  if (!Number.isFinite(weightKg) || !Number.isFinite(heightCm) || weightKg <= 0 || heightCm <= 0) throw new Error('Peso e altura devem ser positivos.');
  const heightM = heightCm / 100;
  const bmi = weightKg / (heightM * heightM);
  const category = bmi < 18.5 ? 'Abaixo do peso' : bmi < 25 ? 'Faixa de referência adequada' : bmi < 30 ? 'Sobrepeso' : 'Obesidade';
  return { bmi: Number(bmi.toFixed(2)), category };
}
export function calculateBMR(weightKg: number, heightCm: number, age: number, sex: 'male'|'female') {
  if (weightKg <= 0 || heightCm <= 0 || age <= 0) throw new Error('Informe peso, altura e idade válidos.');
  return Number((10*weightKg + 6.25*heightCm - 5*age + (sex === 'male' ? 5 : -161)).toFixed(0));
}
export function calculateTDEE(bmr: number, activityFactor: number) {
  if (bmr <= 0 || activityFactor < 1 || activityFactor > 2.5) throw new Error('Parâmetros de atividade inválidos.');
  return Math.round(bmr * activityFactor);
}

export function ageFromBirthDate(birthDate: string | null | undefined, today = new Date()) {
  if (!birthDate) return null;
  const b = new Date(birthDate);
  if (Number.isNaN(b.getTime())) return null;
  let age = today.getFullYear() - b.getFullYear();
  const before = today.getMonth() < b.getMonth() || (today.getMonth() === b.getMonth() && today.getDate() < b.getDate());
  if (before) age -= 1;
  return age > 0 && age < 120 ? age : null;
}

// IMC sempre; TMB/TDEE só quando há idade e sexo (male/female) cadastrados.
export function computeBodyMetrics(input: { weightKg: number; heightCm: number; birthDate?: string | null; sex?: string | null; activityFactor: number }) {
  const { bmi, category } = calculateBMI(input.weightKg, input.heightCm);
  const age = ageFromBirthDate(input.birthDate);
  const sex = input.sex === 'male' || input.sex === 'female' ? input.sex : null;
  if (!age || !sex) return { bmi, category, bmr: null as number | null, tdee: null as number | null };
  const bmr = calculateBMR(input.weightKg, input.heightCm, age, sex);
  return { bmi, category, bmr, tdee: calculateTDEE(bmr, input.activityFactor) };
}
