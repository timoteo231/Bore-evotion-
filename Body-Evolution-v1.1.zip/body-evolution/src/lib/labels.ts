export const objectiveLabel: Record<string, string> = {
  hypertrophy: 'Ganho de massa', weight_loss: 'Emagrecimento', conditioning: 'Condicionamento', maintenance: 'Manutenção',
};
export const levelLabel: Record<string, string> = { beginner: 'Iniciante', intermediate: 'Intermediário', advanced: 'Avançado' };
export const statusLabel: Record<string, string> = { active: 'Ativo', inactive: 'Inativo' };
export const fmtDate = (d: string | null | undefined) => (d ? new Date(d).toLocaleDateString('pt-BR') : '—');
