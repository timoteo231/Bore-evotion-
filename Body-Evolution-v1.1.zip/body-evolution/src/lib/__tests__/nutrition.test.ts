import test from 'node:test';
import assert from 'node:assert/strict';
import { itemMacros, sumMacros } from '../nutrition';

const frango = { serving_unit: 'g', calories: 159, protein_g: 32, carbs_g: 0, fat_g: 2.5 };
const ovo = { serving_unit: 'un', calories: 78, protein_g: 6.3, carbs_g: 0.6, fat_g: 5.3 };

test('alimento em gramas escala por 100 g', () => {
  const m = itemMacros(frango, 150);
  assert.equal(Math.round(m.kcal), 239);
  assert.equal(m.p, 48);
});
test('alimento por unidade escala por quantidade', () => {
  assert.equal(itemMacros(ovo, 2).kcal, 156);
});
test('soma de macros e valores nulos', () => {
  const t = sumMacros([itemMacros(frango, 100), itemMacros({ ...ovo, calories: null }, 1)]);
  assert.equal(t.kcal, 159);
  assert.equal(sumMacros([]).kcal, 0);
});
