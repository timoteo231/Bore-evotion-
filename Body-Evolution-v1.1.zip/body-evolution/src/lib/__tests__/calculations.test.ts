import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateBMI, calculateBMR, calculateTDEE, ageFromBirthDate, computeBodyMetrics } from '../calculations';

test('IMC e categoria', () => {
  assert.deepEqual(calculateBMI(80, 180), { bmi: 24.69, category: 'Faixa de referência adequada' });
  assert.equal(calculateBMI(85, 175).category, 'Sobrepeso');
  assert.throws(() => calculateBMI(0, 180));
});
test('TMB (Mifflin-St Jeor) e TDEE', () => {
  assert.equal(calculateBMR(80, 180, 30, 'male'), 1780);
  assert.equal(calculateBMR(60, 165, 30, 'female'), 1320);
  assert.equal(calculateTDEE(1780, 1.55), 2759);
  assert.throws(() => calculateTDEE(1780, 3));
});
test('idade respeita o aniversário', () => {
  const hoje = new Date('2026-06-10T12:00:00');
  assert.equal(ageFromBirthDate('2000-06-11', hoje), 25);
  assert.equal(ageFromBirthDate('2000-06-10', hoje), 26);
  assert.equal(ageFromBirthDate(null, hoje), null);
});
test('métricas sem sexo/idade devolvem só IMC', () => {
  const m = computeBodyMetrics({ weightKg: 70, heightCm: 170, activityFactor: 1.55 });
  assert.equal(m.bmr, null);
  assert.equal(m.tdee, null);
  assert.ok(m.bmi > 24);
});
