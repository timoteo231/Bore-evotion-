'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

type Student = { id: string; full_name: string };

export default function AssessmentForm({ students, defaultStudentId, defaultHeight }: { students: Student[]; defaultStudentId?: string; defaultHeight?: number | null }) {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const form = e.currentTarget;
    const payload = Object.fromEntries(new FormData(form).entries());
    const response = await fetch('/api/assessments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const result = await response.json();
    setOk(response.ok);
    if (response.ok) {
      const d = result.data;
      setMessage(`Avaliação salva. IMC ${d.bmi} (${d.bmi_category})${d.tdee ? ` · TMB ${d.bmr} kcal · gasto estimado ${d.tdee} kcal` : ' · cadastre sexo e nascimento para calcular TMB/gasto'}.`);
      form.reset(); router.refresh();
    } else setMessage(result.error?.message || 'Erro ao salvar.');
    setBusy(false);
  }

  return <section className="card"><h2>Registrar avaliação física</h2>
    {students.length === 0 ? <p className="muted">Cadastre um aluno antes de registrar avaliações.</p> :
    <form onSubmit={submit}><div className="formrow">
      <label className="field">Aluno<select name="student_id" required defaultValue={defaultStudentId ?? ''}><option value="" disabled>Selecione</option>{students.map((s) => <option key={s.id} value={s.id}>{s.full_name}</option>)}</select></label>
      <label className="field">Peso (kg)<input name="weight_kg" type="number" min="1" max="500" step="0.01" required /></label>
      <label className="field">Altura (cm)<input name="height_cm" type="number" min="1" max="250" step="0.1" required defaultValue={defaultHeight ?? undefined} /></label>
      <label className="field">Atividade<select name="activity_factor" defaultValue="1.55"><option value="1.2">Sedentário</option><option value="1.375">Leve (1–3 dias)</option><option value="1.55">Moderado (3–5 dias)</option><option value="1.725">Intenso (6–7 dias)</option><option value="1.9">Muito intenso</option></select></label>
      <label className="field">Observações<input name="notes" maxLength={2000} /></label></div>
      {message && <p className={ok ? 'ok' : 'danger'} role="status">{message}</p>}
      <button className="btn" disabled={busy}>{busy ? 'Salvando...' : 'Salvar avaliação'}</button></form>}</section>;
}
