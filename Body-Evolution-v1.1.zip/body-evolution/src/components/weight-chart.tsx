'use client';
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function WeightChart({ data }: { data: { date: string; peso: number }[] }) {
  if (data.length < 2) return <p className="muted">Registre ao menos dois pesos para ver o gráfico.</p>;
  return <div style={{ width: '100%', height: 240 }}>
    <ResponsiveContainer>
      <LineChart data={data}>
        <CartesianGrid stroke="#303030" />
        <XAxis dataKey="date" stroke="#a3a3a3" fontSize={12} />
        <YAxis domain={['auto', 'auto']} stroke="#a3a3a3" fontSize={12} width={40} />
        <Tooltip contentStyle={{ background: '#1b1b1b', border: '1px solid #303030' }} formatter={(v) => [`${v} kg`, 'Peso']} />
        <Line type="monotone" dataKey="peso" stroke="#c6a04a" strokeWidth={3} dot />
      </LineChart>
    </ResponsiveContainer>
  </div>;
}
