'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function StudentForm() {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const formElement = e.currentTarget;
    const payload = Object.fromEntries(new FormData(formElement).entries());
    const response = await fetch('/api/students', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const result = await response.json();
    setOk(response.ok);
    setMessage(response.ok ? 'Aluno cadastrado. Abra o aluno na lista para enviar o convite.' : result.error?.message || 'Não foi possível cadastrar.');
    if (response.ok) { formElement.reset(); router.refresh(); }
    setBusy(false);
  }

  return <section className="card"><h2>Novo aluno</h2>
    <form onSubmit={submit}><div className="formrow">
      <label className="field">Nome completo<input name="full_name" required minLength={2} /></label>
      <label className="field">E-mail<input name="email" type="email" required /></label>
      <label className="field">Nascimento<input name="birth_date" type="date" /></label>
      <label className="field">Sexo<select name="sex" defaultValue="not_informed"><option value="male">Masculino</option><option value="female">Feminino</option><option value="other">Outro</option><option value="not_informed">Não informado</option></select></label>
      <label className="field">Altura (cm)<input name="height_cm" type="number" min="1" max="250" step="0.1" /></label>
      <label className="field">Objetivo<select name="objective"><option value="hypertrophy">Ganho de massa</option><option value="weight_loss">Emagrecimento</option><option value="conditioning">Condicionamento</option><option value="maintenance">Manutenção</option></select></label>
    </div>
    <p className="muted sm">Sexo e nascimento permitem calcular TMB e gasto diário. Sem eles, só o IMC é calculado.</p>
    {message && <p className={ok ? 'ok' : 'danger'} role="status">{message}</p>}
    <button className="btn" disabled={busy}>{busy ? 'Salvando...' : 'Cadastrar aluno'}</button></form></section>;
}
