'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AssignPlan({ kind, studentId, plans }: { kind: 'workout' | 'nutrition'; studentId: string; plans: { id: string; name: string }[] }) {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  if (plans.length === 0) return <p className="muted sm">Nenhum plano criado ainda.</p>;

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const plan_id = String(new FormData(e.currentTarget).get('plan_id'));
    const r = await fetch(kind === 'workout' ? '/api/workouts/assign' : '/api/nutrition/assign', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ student_id: studentId, plan_id }),
    });
    const j = await r.json();
    setMessage(r.ok ? j.message : j.error?.message || 'Erro.');
    setBusy(false);
    if (r.ok) router.refresh();
  }

  return <form onSubmit={submit} className="row">
    <select name="plan_id" required defaultValue="" style={{ minWidth: 200 }} className="sel"><option value="" disabled>Escolher plano</option>{plans.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
    <button className="btn" disabled={busy}>Atribuir</button>
    {message && <span className="muted sm" role="status">{message}</span>}
  </form>;
}
