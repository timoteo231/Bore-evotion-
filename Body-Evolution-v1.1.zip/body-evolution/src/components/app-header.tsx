import Link from 'next/link';

export default function AppHeader({ role }: { role: 'admin' | 'student' }) {
  const links = role === 'admin'
    ? [['/admin/alunos', 'Alunos'], ['/admin/treinos', 'Treinos'], ['/admin/dietas', 'Dietas']]
    : [['/aluno', 'Início'], ['/aluno/treino', 'Treino'], ['/aluno/dieta', 'Dieta']];
  return <header className="topbar">
    <Link href="/" className="brand">BODY EVOLUTION</Link>
    <nav className="nav">
      {links.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}
      <form action="/auth/signout" method="post"><button className="btn-secondary">Sair</button></form>
    </nav>
  </header>;
}
