'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

type Food = { id: string; name: string; serving_unit: string };
type Item = { food_item_id: string; quantity: string };
type Meal = { meal_name: string; scheduled_time: string; items: Item[] };
const blank = (): Item => ({ food_item_id: '', quantity: '100' });

export default function NutritionBuilder({ foods }: { foods: Food[] }) {
  const router = useRouter();
  const [meals, setMeals] = useState<Meal[]>([{ meal_name: 'Café da manhã', scheduled_time: '07:30', items: [blank()] }]);
  const [message, setMessage] = useState('');
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);
  const unitOf = (id: string) => foods.find((f) => f.id === id)?.serving_unit ?? 'g';

  const patchMeal = (mi: number, fn: (m: Meal) => Meal) => setMeals((ms) => ms.map((m, i) => (i === mi ? fn(m) : m)));
  const patchItem = (mi: number, ii: number, key: keyof Item, value: string) =>
    patchMeal(mi, (m) => ({ ...m, items: m.items.map((x, i) => (i === ii ? { ...x, [key]: value } : x)) }));

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const form = e.currentTarget;
    const f = new FormData(form);
    const body = {
      name: f.get('name'), objective: f.get('objective'), professional_name: f.get('professional_name'),
      professional_registration: f.get('professional_registration'), notes: f.get('notes') || undefined,
      meals: meals.map((m) => ({ ...m, items: m.items.map((x) => ({ ...x, unit: unitOf(x.food_item_id) })) })),
    };
    const r = await fetch('/api/nutrition', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json();
    setOk(r.ok);
    setMessage(r.ok ? 'Plano criado. Atribua a um aluno na página dele.' : j.error?.message || 'Erro ao salvar.');
    if (r.ok) { form.reset(); setMeals([{ meal_name: 'Café da manhã', scheduled_time: '07:30', items: [blank()] }]); router.refresh(); }
    setBusy(false);
  }

  return <section className="card"><h2>Novo plano alimentar</h2>
    <p className="muted sm">A prescrição deve ser feita ou validada por nutricionista habilitado. Nome e registro (CRN) são obrigatórios.</p>
    <form onSubmit={submit}>
      <div className="formrow">
        <label className="field">Nome do plano<input name="name" required minLength={2} /></label>
        <label className="field">Objetivo<input name="objective" required minLength={2} /></label>
        <label className="field">Nutricionista responsável<input name="professional_name" required minLength={2} /></label>
        <label className="field">Registro (CRN)<input name="professional_registration" required minLength={2} /></label>
        <label className="field">Observações<input name="notes" maxLength={2000} /></label>
      </div>
      {meals.map((m, mi) => <div key={mi} className="card" style={{ marginTop: 14, background: '#151515' }}>
        <div className="row">
          <input className="sel" aria-label="Nome da refeição" value={m.meal_name} onChange={(e) => patchMeal(mi, (x) => ({ ...x, meal_name: e.target.value }))} required />
          <input className="sel" aria-label="Horário" type="time" value={m.scheduled_time} onChange={(e) => patchMeal(mi, (x) => ({ ...x, scheduled_time: e.target.value }))} />
          {meals.length > 1 && <button type="button" className="btn-secondary" onClick={() => setMeals((ms) => ms.filter((_, i) => i !== mi))}>Remover refeição</button>}
        </div>
        {m.items.map((it, ii) => <div key={ii} className="row" style={{ marginTop: 8 }}>
          <select className="sel" aria-label="Alimento" required value={it.food_item_id} onChange={(e) => patchItem(mi, ii, 'food_item_id', e.target.value)} style={{ minWidth: 220 }}>
            <option value="" disabled>Escolher alimento</option>{foods.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
          <input className="sel" aria-label="Quantidade" type="number" min="1" step="any" style={{ width: 100 }} value={it.quantity} onChange={(e) => patchItem(mi, ii, 'quantity', e.target.value)} required />
          <span className="muted sm">{unitOf(it.food_item_id)}</span>
          <button type="button" className="x" aria-label="Remover item" disabled={m.items.length === 1} onClick={() => patchMeal(mi, (x) => ({ ...x, items: x.items.filter((_, i) => i !== ii) }))}>×</button>
        </div>)}
        <button type="button" className="btn-secondary" style={{ marginTop: 10 }} onClick={() => patchMeal(mi, (x) => ({ ...x, items: [...x.items, blank()] }))}>+ Alimento</button>
      </div>)}
      <div className="row" style={{ marginTop: 14 }}>
        <button type="button" className="btn-secondary" disabled={meals.length >= 10} onClick={() => setMeals((ms) => [...ms, { meal_name: `Refeição ${ms.length + 1}`, scheduled_time: '', items: [blank()] }])}>+ Refeição</button>
        <button className="btn" disabled={busy}>{busy ? 'Salvando...' : 'Salvar plano'}</button>
      </div>
      {message && <p className={ok ? 'ok' : 'danger'} role="status">{message}</p>}
    </form></section>;
}
