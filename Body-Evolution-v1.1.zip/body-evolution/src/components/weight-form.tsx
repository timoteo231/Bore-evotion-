'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

// O aluno grava só o próprio peso; a RLS (progress_student_own) impede gravar para outro aluno.
export default function WeightForm({ studentId }: { studentId: string }) {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const form = e.currentTarget;
    const w = Number(new FormData(form).get('weight'));
    if (!(w > 0 && w <= 500)) { setMessage('Informe um peso válido.'); setBusy(false); return; }
    const { error } = await createClient().from('progress_records').insert({ student_id: studentId, weight_kg: w });
    setMessage(error ? 'Não foi possível salvar.' : 'Peso registrado.');
    if (!error) { form.reset(); router.refresh(); }
    setBusy(false);
  }

  return <form onSubmit={submit} className="row">
    <input name="weight" type="number" step="0.1" min="1" max="500" placeholder="Peso (kg)" required className="sel" style={{ width: 140 }} />
    <button className="btn" disabled={busy}>Registrar peso</button>
    {message && <span className="muted sm" role="status">{message}</span>}
  </form>;
}
