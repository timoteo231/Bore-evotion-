'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

type Ex = { id: string; name: string; muscle_group: string };
type Row = { exercise_id: string; sets: string; reps_min: string; reps_max: string; rest_seconds: string };
type Day = { day_name: string; exercises: Row[] };
const blank = (): Row => ({ exercise_id: '', sets: '3', reps_min: '8', reps_max: '12', rest_seconds: '60' });

export default function WorkoutBuilder({ exercises }: { exercises: Ex[] }) {
  const router = useRouter();
  const [days, setDays] = useState<Day[]>([{ day_name: 'Treino A', exercises: [blank()] }]);
  const [message, setMessage] = useState('');
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);
  const groups = Array.from(new Set(exercises.map((e) => e.muscle_group)));

  const patchDay = (di: number, fn: (d: Day) => Day) => setDays((ds) => ds.map((d, i) => (i === di ? fn(d) : d)));
  const patchRow = (di: number, ri: number, key: keyof Row, value: string) =>
    patchDay(di, (d) => ({ ...d, exercises: d.exercises.map((r, i) => (i === ri ? { ...r, [key]: value } : r)) }));

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const f = new FormData(e.currentTarget);
    const body = { name: f.get('name'), level: f.get('level'), objective: f.get('objective'), description: f.get('description') || undefined, days };
    const r = await fetch('/api/workouts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json();
    setOk(r.ok);
    setMessage(r.ok ? 'Ficha criada. Atribua a um aluno na página dele.' : j.error?.message || 'Erro ao salvar.');
    if (r.ok) { setDays([{ day_name: 'Treino A', exercises: [blank()] }]); (e.target as HTMLFormElement).reset?.(); router.refresh(); }
    setBusy(false);
  }

  return <section className="card"><h2>Nova ficha de treino</h2>
    <form onSubmit={submit}>
      <div className="formrow">
        <label className="field">Nome da ficha<input name="name" required minLength={2} placeholder="Hipertrofia ABC" /></label>
        <label className="field">Nível<select name="level" defaultValue="beginner"><option value="beginner">Iniciante</option><option value="intermediate">Intermediário</option><option value="advanced">Avançado</option></select></label>
        <label className="field">Objetivo<input name="objective" required minLength={2} placeholder="Ganho de massa" /></label>
        <label className="field">Descrição<input name="description" maxLength={1000} /></label>
      </div>
      {days.map((d, di) => <div key={di} className="card" style={{ marginTop: 14, background: '#151515' }}>
        <div className="row">
          <input className="sel" aria-label="Nome do dia" value={d.day_name} onChange={(e) => patchDay(di, (x) => ({ ...x, day_name: e.target.value }))} required />
          {days.length > 1 && <button type="button" className="btn-secondary" onClick={() => setDays((ds) => ds.filter((_, i) => i !== di))}>Remover dia</button>}
        </div>
        <div className="muted sm" style={{ marginTop: 10 }}>Exercício · séries · reps mín · reps máx · descanso (s)</div>
        {d.exercises.map((r, ri) => <div key={ri} className="exrow">
          <select className="sel" aria-label="Exercício" required value={r.exercise_id} onChange={(e) => patchRow(di, ri, 'exercise_id', e.target.value)}>
            <option value="" disabled>Escolher exercício</option>
            {groups.map((g) => <optgroup key={g} label={g}>{exercises.filter((x) => x.muscle_group === g).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</optgroup>)}
          </select>
          {(['sets', 'reps_min', 'reps_max', 'rest_seconds'] as const).map((k) =>
            <input key={k} className="sel" aria-label={k} type="number" min={k === 'rest_seconds' ? 0 : 1} value={r[k]} onChange={(e) => patchRow(di, ri, k, e.target.value)} required />)}
          <button type="button" className="x" aria-label="Remover exercício" onClick={() => patchDay(di, (x) => ({ ...x, exercises: x.exercises.filter((_, i) => i !== ri) }))} disabled={d.exercises.length === 1}>×</button>
        </div>)}
        <button type="button" className="btn-secondary" onClick={() => patchDay(di, (x) => ({ ...x, exercises: [...x.exercises, blank()] }))}>+ Exercício</button>
      </div>)}
      <div className="row" style={{ marginTop: 14 }}>
        <button type="button" className="btn-secondary" disabled={days.length >= 7} onClick={() => setDays((ds) => [...ds, { day_name: `Treino ${String.fromCharCode(65 + ds.length)}`, exercises: [blank()] }])}>+ Dia</button>
        <button className="btn" disabled={busy}>{busy ? 'Salvando...' : 'Salvar ficha'}</button>
      </div>
      {message && <p className={ok ? 'ok' : 'danger'} role="status">{message}</p>}
    </form></section>;
}
