'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function StudentActions({ studentId, hasAccount, status }: { studentId: string; hasAccount: boolean; status: string }) {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function call(url: string, method: string, body?: object) {
    setBusy(true); setMessage('');
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json();
    setMessage(r.ok ? j.message || 'Feito.' : j.error?.message || 'Erro.');
    setBusy(false);
    if (r.ok) router.refresh();
  }

  const next = status === 'active' ? 'inactive' : 'active';
  return <div>
    <div className="row">
      {!hasAccount && status === 'active' && <button className="btn" disabled={busy} onClick={() => call(`/api/students/${studentId}/invite`, 'POST')}>Enviar convite por e-mail</button>}
      <button className="btn-secondary" disabled={busy} onClick={() => { if (next === 'active' || confirm('Inativar este aluno?')) call(`/api/students/${studentId}`, 'PATCH', { status: next }); }}>
        {status === 'active' ? 'Inativar aluno' : 'Reativar aluno'}
      </button>
    </div>
    {message && <p className="muted" role="status">{message}</p>}
  </div>;
}
