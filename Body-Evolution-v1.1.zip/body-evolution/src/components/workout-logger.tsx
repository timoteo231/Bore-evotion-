'use client';
import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';

export type PlanExercise = { id: string; exercise_id: string; sets: number; reps_min: number; reps_max: number; rest_seconds: number; name: string };
export type PlanDay = { id: string; day_name: string; exercises: PlanExercise[] };
type SetRow = { weight: string; reps: string };

export default function WorkoutLogger({ assignmentId, days }: { assignmentId: string; days: PlanDay[] }) {
  const router = useRouter();
  const [dayId, setDayId] = useState(days[0]?.id ?? '');
  const [rows, setRows] = useState<Record<string, SetRow[]>>({});
  const [message, setMessage] = useState('');
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);
  const [rest, setRest] = useState(0);
  const startedAt = useRef(Date.now());
  const day = days.find((d) => d.id === dayId);

  useEffect(() => {
    if (rest <= 0) return;
    const t = setTimeout(() => { setRest(rest - 1); if (rest === 1 && navigator.vibrate) navigator.vibrate(300); }, 1000);
    return () => clearTimeout(t);
  }, [rest]);

  const rowsFor = (ex: PlanExercise): SetRow[] => rows[ex.id] ?? Array.from({ length: ex.sets }, () => ({ weight: '', reps: '' }));
  const setCell = (ex: PlanExercise, i: number, key: keyof SetRow, v: string) =>
    setRows((r) => ({ ...r, [ex.id]: rowsFor(ex).map((x, j) => (j === i ? { ...x, [key]: v } : x)) }));

  async function finish() {
    if (!day) return;
    const sets = day.exercises.flatMap((ex) => rowsFor(ex).map((r, i) => ({
      exercise_id: ex.exercise_id, set_number: i + 1, weight_kg: r.weight === '' ? null : Number(r.weight), repetitions: Number(r.reps),
    })).filter((s) => s.repetitions > 0));
    if (sets.length === 0) { setOk(false); setMessage('Preencha ao menos uma série (repetições).'); return; }
    setBusy(true); setMessage('');
    const duration = Math.max(1, Math.round((Date.now() - startedAt.current) / 60000));
    const r = await fetch('/api/workout-logs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ assignment_id: assignmentId, duration_minutes: duration, sets }) });
    const j = await r.json();
    setOk(r.ok);
    setMessage(r.ok ? 'Treino salvo. Bom trabalho!' : j.error?.message || 'Erro ao salvar.');
    if (r.ok) { setRows({}); startedAt.current = Date.now(); router.refresh(); }
    setBusy(false);
  }

  if (!day) return <p className="muted">Esta ficha não tem dias cadastrados.</p>;
  return <div>
    <div className="row" style={{ marginBottom: 14 }}>
      {days.map((d) => <button key={d.id} className={d.id === dayId ? 'btn' : 'btn-secondary'} onClick={() => setDayId(d.id)}>{d.day_name}</button>)}
      <span className="badge" aria-live="polite">{rest > 0 ? `Descanso ${rest}s` : 'Sem descanso ativo'}</span>
    </div>
    {day.exercises.map((ex) => <div key={ex.id} className="card" style={{ marginBottom: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <b>{ex.name}</b><span className="muted sm">{ex.sets}×{ex.reps_min === ex.reps_max ? ex.reps_min : `${ex.reps_min}-${ex.reps_max}`} · descanso {ex.rest_seconds}s</span>
      </div>
      {rowsFor(ex).map((r, i) => <div key={i} className="row" style={{ marginTop: 8 }}>
        <span className="muted sm" style={{ width: 52 }}>Série {i + 1}</span>
        <input className="sel" style={{ width: 92 }} type="number" inputMode="decimal" min="0" step="0.5" placeholder="kg" aria-label={`Carga série ${i + 1}`} value={r.weight} onChange={(e) => setCell(ex, i, 'weight', e.target.value)} />
        <input className="sel" style={{ width: 92 }} type="number" inputMode="numeric" min="0" placeholder="reps" aria-label={`Repetições série ${i + 1}`} value={r.reps} onChange={(e) => setCell(ex, i, 'reps', e.target.value)} />
        <button className="btn-secondary" type="button" onClick={() => setRest(ex.rest_seconds)} disabled={!r.reps}>Descansar</button>
      </div>)}
    </div>)}
    {message && <p className={ok ? 'ok' : 'danger'} role="status">{message}</p>}
    <button className="btn" onClick={finish} disabled={busy}>{busy ? 'Salvando...' : 'Finalizar treino'}</button>
  </div>;
}
